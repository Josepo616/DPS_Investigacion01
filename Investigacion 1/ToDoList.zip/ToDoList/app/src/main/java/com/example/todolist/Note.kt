package com.example.todolist

data class Note(val id: Int, val tittle:String, val content: String)

